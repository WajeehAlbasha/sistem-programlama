to start the project on ubuntu linux
1: right click in the file and open terminal
2:write "make"
write "bin/transfer txt/input.txt output.txt"
