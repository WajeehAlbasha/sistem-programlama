#include <stdio.h>
#include <stdlib.h>
#include "fields.h"
#include "dllist.h"
#include <string.h>

// input dosyasinda tanimlanan karakterleri listeye atar ve listeyi dondurur.
Dllist ReadChars(IS is);

// Arguman kontrolu yapan fonksiyon
void CheckArgument(int argc, char **argv);

// Listedeki elemanlari dosyaya yazdiran fonksiyon
void WriteToFile(Dllist dl,char * filename);

// listeye yazdirilacak elemanlari ekleyen fonksiyon
void AddWriteList(Dllist dl,Dllist chars,IS is,int width);

// yazdirilacak karakterin input dosyasinda tanimlanip tanimlanmadigina bakar.
int CheckChar(Dllist dl,char* character);

int main(int argc, char **argv) {

   CheckArgument(argc,argv);

   IS is;

   is = new_inputstruct(argv[1]);

   if (is == NULL) 
   {
      perror(argv[1]);
      exit(1);
   }
   int height = 0;
   int width = 0;

   int heightCounter=0;

   Dllist chars = new_dllist();
   Dllist prints = new_dllist();

   while(get_line(is) >= 0) 
   {
      if(is -> NF > 1)
      {
         if(!(strcmp(is->fields[0],"boyut")||strcmp(is->fields[1],"bilgisi:")))
         {
            if(is->NF>=4)
            {
               height = atoi(is->fields[2]);
               width = atoi(is->fields[3]);
            }
         }  
         
         else if(!(strcmp(is->fields[0],"karakterler:")))
         {
            chars = ReadChars(is);
         }
         else
         {
            AddWriteList(prints,chars,is,width);
            heightCounter+= 1;
         }
      }
   }

   if (heightCounter!=height)
   {
      printf("Yukseklik degeri input dosyasinda tanimlanan degerden farklidir\n");
      exit(1);
   }

   jettison_inputstruct(is);

   WriteToFile(prints,argv[2]);

   
   free_dllist(chars);
   free_dllist(prints);

   return 0;
}


// input dosyasinda tanimlanan karakterleri listeye atar ve listeyi dondurur.
Dllist ReadChars(IS is)
{
   Dllist dl = new_dllist();

   if(is->NF>1)
   {
      for(int i = 1;i<is->NF;i++)
      {
         dll_append(dl,new_jval_s(strdup(is->fields[i])));
      }
   }
   return dl;

}
// Arguman kontrolu yapan fonksiyon
void CheckArgument(int argc, char **argv)
{
   if (argc != 3 || (strcmp(argv[1],"txt/input.txt") || strcmp(argv[2],"txt/output.txt")))
   { 
      fprintf(stderr, "usage: bin/transfer txt/input.txt txt/output.txt\n"); exit(1); 
   }
}
// Listedeki elemanlari dosyaya yazdiran fonksiyon
void WriteToFile(Dllist dl,char * filename)
{
   FILE *fptr;

   fptr = fopen(filename,"w");
   
   Dllist dtmp = dl->flink;

   while (dtmp != dl) 
   {
      fprintf(fptr,"%s",dtmp->val.s);
      dtmp = dtmp->flink;
   }

   fclose(fptr);
}
// yazdirilacak karakterin input dosyasinda tanimlanip tanimlanmadigina bakar.
int CheckChar(Dllist dl,char* character)
{
   int checkValue = 0;

   Dllist dtmp = dl->flink;

   while(dtmp!=dl)
   {
      if(!strcmp(dtmp->val.s,character))
      {
         checkValue = 1;
      }
      dtmp = dtmp->flink;
   }
   return checkValue;
}
// listeye yazdirilacak elemanlari ekleyen fonksiyon
void AddWriteList(Dllist dl,Dllist chars,IS is,int width)
{
   int count = 0;
   int widthCounter=0;

   char * character;

   for(int i = 0;i<is->NF;i++)
   {
      if(i%2==0)
      {
         count = atoi(is->fields[i]);
         widthCounter = widthCounter + count;
      }
      else
      {
         character = strdup(is->fields[i]);

         if(CheckChar(chars,character))
         {
            if(!strcmp(character,"s"))
            {
               character = " ";
            } 

            for(int j = 0;j<count;j++)
            {
               dll_append(dl,new_jval_s(character));
            }

         }
         else
         {
            
            printf("%s Karakteri input dosyasinda tanimlanmamistir luften tanimlayiniz\n",character);
            exit(1);
         }
      }
      
   }
   if(widthCounter!=width)
   {
      printf("Genislik degeri input dosyasinda tanimlanan degerden farklidir\n");
      exit(1);
   }
   dll_append(dl,new_jval_s("\n"));
   
}
